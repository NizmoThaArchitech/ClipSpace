
import React, { useMemo, useState, useEffect, useRef } from 'react';
import type { AuthView } from '../../AuthApp';
import { ClipspaceLogo } from '../icons/ClipspaceLogo';

interface LoginProps {
  setAuthView: (view: AuthView) => void;
  onLoginSuccess: () => void;
}

// Visual Node Components - Pure White Thinner Outlines
const LaptopIcon = ({ x, y }: { x: number; y: number }) => (
  <g transform={`translate(${x - 12}, ${y - 12})`} className="opacity-30">
    <rect x="3" y="6" width="18" height="11" rx="0.5" fill="none" stroke="white" strokeWidth="0.8" />
    <path d="M1 18h22c0-0.5-0.5-1-1-1H2c-0.5 0-1 0.5-1 1z" fill="white" opacity="0.8" />
    <rect x="10" y="8" width="4" height="3" fill="white" opacity="0.1" />
  </g>
);

const ServerIcon = ({ x, y }: { x: number; y: number }) => (
  <g transform={`translate(${x - 12}, ${y - 12})`} className="opacity-30">
    <rect x="5" y="3" width="14" height="18" rx="0.5" fill="none" stroke="white" strokeWidth="0.8" />
    <line x1="5" y1="9" x2="19" y2="9" stroke="white" strokeWidth="0.5" />
    <line x1="5" y1="15" x2="19" y2="15" stroke="white" strokeWidth="0.5" />
    <circle cx="8" cy="6" r="0.4" fill="white" />
    <circle cx="8" cy="12" r="0.4" fill="white" />
    <circle cx="8" cy="18" r="0.4" fill="white" />
  </g>
);

const PCIcon = ({ x, y }: { x: number; y: number }) => (
  <g transform={`translate(${x - 12}, ${y - 12})`} className="opacity-30">
    <rect x="4" y="4" width="16" height="12" rx="0.5" fill="none" stroke="white" strokeWidth="0.8" />
    <path d="M8 20h8M12 16v4" stroke="white" strokeWidth="0.8" />
    <rect x="7" y="7" width="10" height="6" fill="white" opacity="0.1" />
  </g>
);

const GlobeWireframe = ({ x, y, size = 40 }: { x: number; y: number; size?: number }) => (
  <g transform={`translate(${x}, ${y})`} className="animate-globe-spin opacity-20">
    <circle cx="0" cy="0" r={size} fill="none" stroke="white" strokeWidth="0.3" />
    <ellipse cx="0" cy="0" rx={size} ry={size / 2.5} fill="none" stroke="white" strokeWidth="0.3" />
    <ellipse cx="0" cy="0" rx={size / 2.5} ry={size} fill="none" stroke="white" strokeWidth="0.3" />
    <line x1={-size} y1="0" x2={size} y2="0" stroke="white" strokeWidth="0.2" opacity="0.5" />
    <line x1="0" y1={-size} x2="0" y2={size} stroke="white" strokeWidth="0.2" opacity="0.5" />
  </g>
);

interface Node {
  id: number;
  x: number;
  y: number;
  type: 'laptop' | 'server' | 'pc' | 'globe';
}

interface Spark {
  id: string;
  startX: number;
  startY: number;
  endX: number;
  endY: number;
}

const BackgroundSystem: React.FC = () => {
  const [nodes, setNodes] = useState<Node[]>([]);
  const [sparks, setSparks] = useState<Spark[]>([]);
  const nextSparkId = useRef(0);

  // Initialize nodes and globes randomly across viewport
  useEffect(() => {
    const types: ('laptop' | 'server' | 'pc' | 'globe')[] = ['laptop', 'server', 'pc', 'globe'];
    const newNodes: Node[] = Array.from({ length: 45 }).map((_, i) => ({
      id: i,
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      type: types[Math.floor(Math.random() * types.length)],
    }));
    setNodes(newNodes);
  }, []);

  // Spawn transmissions periodically
  useEffect(() => {
    if (nodes.length === 0) return;

    const spawnSpark = () => {
      const start = nodes[Math.floor(Math.random() * nodes.length)];
      const end = nodes[Math.floor(Math.random() * nodes.length)];
      if (start.id === end.id) return;

      const id = `spark-${nextSparkId.current++}`;
      const newSpark: Spark = { id, startX: start.x, startY: start.y, endX: end.x, endY: end.y };
      
      setSparks(prev => [...prev, newSpark]);
      
      // Cleanup spark after animation completes
      setTimeout(() => {
        setSparks(prev => prev.filter(s => s.id !== id));
      }, 2500);
    };

    const interval = setInterval(spawnSpark, 300);
    return () => clearInterval(interval);
  }, [nodes]);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-0 bg-gray-700">
      <svg className="w-full h-full">
        {/* Render Circuit Grid Pattern */}
        <defs>
          <pattern id="circuit-grid" width="80" height="80" patternUnits="userSpaceOnUse">
            <path d="M 80 0 L 0 0 0 80" fill="none" stroke="white" strokeWidth="0.3" opacity="0.04" />
            <circle cx="0" cy="0" r="1" fill="white" opacity="0.08" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#circuit-grid)" />

        {/* Render Active Sparks/Transmissions - Thinner Lines */}
        {sparks.map(spark => (
          <g key={spark.id}>
            <path
              d={`M${spark.startX} ${spark.startY} L${spark.endX} ${spark.endY}`}
              stroke="white"
              strokeWidth="0.3"
              fill="none"
              className="animate-path-flow"
              opacity="0"
            />
            {/* Main Spark Point */}
            <circle r="1.5" fill="white" className="animate-spark-pulse">
              <animateMotion
                path={`M${spark.startX} ${spark.startY} L${spark.endX} ${spark.endY}`}
                dur="2s"
                repeatCount="1"
                fill="freeze"
              />
            </circle>
            {/* Electricity Glow Halo */}
            <circle r="4" fill="white" opacity="0.2">
               <animateMotion
                path={`M${spark.startX} ${spark.startY} L${spark.endX} ${spark.endY}`}
                dur="2s"
                repeatCount="1"
                fill="freeze"
              />
            </circle>
          </g>
        ))}

        {/* Render All Props (Devices + Globes) */}
        {nodes.map(node => (
          <React.Fragment key={node.id}>
            {node.type === 'laptop' && <LaptopIcon x={node.x} y={node.y} />}
            {node.type === 'server' && <ServerIcon x={node.x} y={node.y} />}
            {node.type === 'pc' && <PCIcon x={node.x} y={node.y} />}
            {node.type === 'globe' && <GlobeWireframe x={node.x} y={node.y} size={Math.random() * 20 + 20} />}
          </React.Fragment>
        ))}
      </svg>
      <style>{`
        @keyframes globeSpin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-globe-spin {
          transform-origin: center;
          animation: globeSpin 40s linear infinite;
        }
        @keyframes pathFlow {
          0% { stroke-dasharray: 0 2000; opacity: 0; }
          15% { opacity: 0.5; }
          85% { opacity: 0.5; }
          100% { stroke-dasharray: 2000 0; opacity: 0; }
        }
        .animate-path-flow {
          animation: pathFlow 2s forwards ease-in-out;
          stroke-dasharray: 2000;
        }
        @keyframes sparkPulse {
          0%, 100% { transform: scale(1); opacity: 0.9; filter: blur(0px); }
          50% { transform: scale(2.2); opacity: 1; filter: blur(1px); }
        }
        .animate-spark-pulse {
          animation: sparkPulse 0.15s infinite;
        }
      `}</style>
    </div>
  );
};

const Login: React.FC<LoginProps> = ({ setAuthView, onLoginSuccess }) => {
  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center bg-gray-700 overflow-hidden min-h-screen">
      <BackgroundSystem />
      
      {/* Auth Card - Strictly NO shadows as requested */}
      <div className="w-full max-w-[440px] mx-auto py-12 px-16 relative z-10 bg-[#161d2f]/95 backdrop-blur-[80px] border border-white/10 rounded-[4rem] shadow-none">
        <div className="text-center mb-10">
          <div className="bg-white/5 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 border border-white/10 shadow-none">
             <ClipspaceLogo className="h-14 w-14" theme="dark" />
          </div>
          <h1 className="text-5xl font-black tracking-tighter uppercase italic text-white leading-none">
            Clip<span className="text-white/60">Space</span>
          </h1>
          <p className="text-gray-400 mt-4 font-black uppercase text-[10px] tracking-[0.7em] italic">Multi-Node Production Mesh</p>
        </div>

        <div className="space-y-8">
          <div className="text-center">
            <h2 className="text-white text-lg font-black uppercase tracking-widest mb-2 italic">Signal Bridge Active</h2>
            <p className="text-gray-400 text-[10px] font-bold uppercase tracking-widest leading-relaxed opacity-70">
                Network authentication verified. Press the terminal initialization button to enter the global production hub.
            </p>
          </div>
          
          <button 
            onClick={onLoginSuccess}
            className="w-full flex justify-center py-8 px-4 border border-white/20 rounded-[2.5rem] text-[12px] font-black uppercase tracking-[0.5em] text-white bg-white/5 hover:bg-white/10 transition-all active:scale-95 group overflow-hidden relative shadow-none"
          >
            <span className="relative z-10">Initialize Terminal</span>
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
          </button>
        </div>

        <div className="mt-14 flex items-center justify-center gap-4">
            <div className="h-[1px] w-12 bg-white/10"></div>
            <p className="text-center text-[9px] font-black text-gray-500 uppercase tracking-[0.4em]">Node Protocol V4.2.1-GOLD</p>
            <div className="h-[1px] w-12 bg-white/10"></div>
        </div>
      </div>
    </div>
  );
};

export default Login;
