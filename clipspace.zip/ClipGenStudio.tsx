
import React, { useState, useEffect, useRef } from 'react';
import type { Theme } from '../App';
import { MOCK_VIDEO_CLIPS, MOCK_USERS, TUTORIAL_STEPS } from '../constants';
import { SparklesIcon } from './icons/SparklesIcon';
import { ChevronDownIcon } from './icons/ChevronDownIcon';
import { CubeTransparentIcon } from './icons/CubeTransparentIcon';
import { FilmIcon } from './icons/FilmIcon';
import { PaintBrushIcon } from './icons/PaintBrushIcon';
import { PencilSquareIcon } from './icons/PencilSquareIcon';

const loadingStates = [
    { state: 'parsing_prompt', message: 'Analyzing prompt for key elements...' },
    { state: 'generating_storyboard', message: 'Creating initial shot composition...' },
    { state: 'rendering_frames', message: 'Rendering frames with diffusion model...' },
    { state: 'interpolating_motion', message: 'Applying motion vectors...' },
];

const TutorialTooltip: React.FC<{ step: any, onNext: () => void, onSkip: () => void, isActionCompleted: boolean }> = ({ step, onNext, onSkip, isActionCompleted }) => {
    return (
        <div className="absolute z-50 p-4 bg-gray-900 border-2 border-indigo-500 rounded-lg shadow-2xl max-w-sm" style={step.position}>
             <div className="absolute w-4 h-4 bg-gray-900 border-l-2 border-b-2 border-indigo-500 transform rotate-45" style={step.arrow}></div>
            <p className="text-white mb-4">{step.text}</p>
            <div className="flex justify-between items-center">
                <button onClick={onSkip} className="text-xs text-gray-500 hover:text-white">Skip Tutorial</button>
                <button onClick={onNext} disabled={!isActionCompleted} className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-1 px-3 rounded-md text-sm disabled:bg-indigo-400 disabled:cursor-not-allowed">
                    Next
                </button>
            </div>
        </div>
    );
};


const ClipGenStudio: React.FC<{ theme: Theme }> = ({ theme }) => {
    const [prompt, setPrompt] = useState('');
    const [generationState, setGenerationState] = useState('idle');
    const [generatedClip, setGeneratedClip] = useState<any | null>(null);
    const [loadingMessage, setLoadingMessage] = useState('');
    const [activeTab, setActiveTab] = useState<'generate' | 'co-director' | 'edit'>('generate');
    const [timelineClips, setTimelineClips] = useState<any[]>([]);
    
    // Tutorial State
    const [tutorialStep, setTutorialStep] = useState<number | null>(null);
    const promptRef = useRef<HTMLTextAreaElement>(null);
    
    const isActionCompleted = () => {
        if (tutorialStep === null) return true;
        const currentStep = TUTORIAL_STEPS[tutorialStep];
        if (!currentStep.awaitsAction) return true;
        if (currentStep.awaitsAction === 'prompt_filled') return prompt.trim() !== '';
        return false;
    };

    useEffect(() => {
        let interval: number;
        if (generationState !== 'idle' && generationState !== 'success') {
            let stateIndex = loadingStates.findIndex(s => s.state === generationState);
            interval = window.setInterval(() => {
                stateIndex++;
                if (stateIndex < loadingStates.length) {
                    setGenerationState(loadingStates[stateIndex].state);
                    setLoadingMessage(loadingStates[stateIndex].message);
                } else {
                    clearInterval(interval);
                    const clip = { ...MOCK_VIDEO_CLIPS[Math.floor(Math.random() * MOCK_VIDEO_CLIPS.length)], creator: MOCK_USERS.jane_creator, title: `AI: ${prompt.substring(0, 30)}...`};
                    setGeneratedClip(clip);
                    setGenerationState('success');
                }
            }, 2000);
        }
        return () => clearInterval(interval);
    }, [generationState]);

    const handleGenerate = () => {
        if (!prompt.trim()) return;
        setGeneratedClip(null);
        setGenerationState('parsing_prompt');
        setLoadingMessage(loadingStates[0].message);
    };
    
    const handleTutorialNext = () => {
        if (tutorialStep === null) return;
        const nextStep = tutorialStep + 1;
        if (nextStep < TUTORIAL_STEPS.length) {
            const step = TUTORIAL_STEPS[nextStep];
            if (step.action) {
                step.action({ setActiveTab });
            }
            setTutorialStep(nextStep);
        } else {
            setTutorialStep(null); // End tutorial
        }
    };

    const CameraControl: React.FC<{ label: string; options: string[]}> = ({label, options}) => (
        <div>
            <label className="text-xs font-semibold text-gray-400">{label}</label>
            <select className="mt-1 w-full bg-gray-700 text-white text-sm rounded-md border-gray-600 focus:ring-indigo-500 focus:border-indigo-500">
                {options.map(opt => <option key={opt}>{opt}</option>)}
            </select>
        </div>
    );

    return (
        <div className="p-4 sm:p-6 lg:p-8 space-y-8 h-full flex flex-col">
            {tutorialStep !== null && (
                 <div className="fixed inset-0 bg-black/70 z-40 backdrop-blur-sm">
                    <div className="relative w-full h-full">
                        {TUTORIAL_STEPS[tutorialStep] && (
                             <TutorialTooltip 
                                step={TUTORIAL_STEPS[tutorialStep]}
                                onNext={handleTutorialNext}
                                onSkip={() => setTutorialStep(null)}
                                isActionCompleted={isActionCompleted()}
                            />
                        )}
                    </div>
                 </div>
            )}
            <div className="flex-shrink-0 flex justify-between items-start">
                <div>
                    <h1 className="text-3xl font-bold text-white flex items-center gap-3"><SparklesIcon className="w-8 h-8 text-indigo-400"/> ClipGen AI Studio</h1>
                    <p className="text-gray-400 mt-1">Your all-in-one AI video creation suite.</p>
                </div>
                <button onClick={() => setTutorialStep(0)} className="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg">Show Me How</button>
            </div>

            <div className="flex-grow grid grid-cols-1 lg:grid-cols-[24rem_1fr_20rem] gap-6 min-h-0">
                {/* Left Panel: Control Tower */}
                <div id="control-tower" className="bg-gray-800 rounded-lg border border-gray-700/50 flex flex-col">
                    <div className="flex border-b border-gray-700/50">
                        <button id="tab-generate" onClick={() => setActiveTab('generate')} className={`flex-1 p-3 text-sm font-semibold flex items-center justify-center gap-2 ${activeTab === 'generate' ? 'bg-gray-700/50 text-white' : 'text-gray-400 hover:bg-gray-700/20'}`}><SparklesIcon className="w-5 h-5"/> Generate</button>
                        <button id="tab-co-director" onClick={() => setActiveTab('co-director')} className={`flex-1 p-3 text-sm font-semibold flex items-center justify-center gap-2 ${activeTab === 'co-director' ? 'bg-gray-700/50 text-white' : 'text-gray-400 hover:bg-gray-700/20'}`}><FilmIcon className="w-5 h-5"/> Co-Director</button>
                        <button id="tab-edit" onClick={() => setActiveTab('edit')} className={`flex-1 p-3 text-sm font-semibold flex items-center justify-center gap-2 ${activeTab === 'edit' ? 'bg-gray-700/50 text-white' : 'text-gray-400 hover:bg-gray-700/20'}`}><PaintBrushIcon className="w-5 h-5"/> Edit</button>
                    </div>
                    <div className="p-4 space-y-4 overflow-y-auto">
                        {activeTab === 'generate' && (
                             <>
                                <div>
                                    <label htmlFor="prompt" className="block text-sm font-medium text-gray-300 mb-2">Describe Your Vision</label>
                                    <textarea ref={promptRef} id="prompt-input" rows={5} value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="e.g., A cinematic slow-motion shot of a bald eagle landing on a branch..." className="w-full bg-gray-700 text-white placeholder-gray-400 rounded-lg p-3 border-2 border-gray-600 focus:outline-none focus:border-indigo-500"/>
                                </div>
                                <div className="space-y-3 pt-3 border-t border-gray-700/50">
                                    <h4 className="text-sm font-semibold text-gray-400">Advanced Controls</h4>
                                    <div className="grid grid-cols-2 gap-3"><CameraControl label="Lens" options={['35mm', '50mm', '85mm']} /><CameraControl label="Angle" options={['Eye Level', 'Low Angle', 'High Angle']} /></div>
                                    <CameraControl label="Motion" options={['Static', 'Pan Left', 'Dolly In', 'Crane Up']} />
                                    <div><label className="text-xs font-semibold text-gray-400">Chaos: 50</label><input type="range" min="0" max="100" defaultValue="50" className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-indigo-500" /></div>
                                </div>
                                <button onClick={handleGenerate} disabled={generationState !== 'idle' && generationState !== 'success' || !prompt} id="generate-button" className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors disabled:bg-indigo-400 disabled:cursor-not-allowed"><SparklesIcon className="w-5 h-5"/> Generate</button>
                             </>
                        )}
                         {activeTab === 'co-director' && (
                             <div>
                                <label className="block text-sm font-medium text-gray-300 mb-2">Enter Your Script (one scene per line)</label>
                                <textarea id="co-director-input" rows={10} className="w-full bg-gray-700 text-gray-200 rounded-lg p-3 border border-gray-600" placeholder="A drone flies over mountains.&#10;A coffee is poured in slow motion." />
                                <button className="w-full mt-2 flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 rounded-lg"><SparklesIcon className="w-5 h-5" /> Generate Storyboard</button>
                             </div>
                         )}
                         {activeTab === 'edit' && (
                            <div className="text-center text-gray-500 p-4">
                                <PencilSquareIcon className="w-10 h-10 mx-auto mb-2" />
                                <p>Generate a clip first to enable editing tools.</p>
                            </div>
                         )}
                    </div>
                </div>

                {/* Center Panel: Canvas */}
                <div id="canvas" className="bg-black rounded-lg flex items-center justify-center relative overflow-hidden">
                    {generationState !== 'idle' && generationState !== 'success' && (
                        <div className="text-center text-indigo-400">
                             <div className="relative w-24 h-24 mx-auto"><div className="absolute inset-0 border-4 border-indigo-500/30 rounded-full"></div><div className="absolute inset-0 border-t-4 border-indigo-500 rounded-full animate-spin"></div></div>
                             <p className="mt-4 font-semibold">{loadingMessage}</p>
                        </div>
                    )}
                    {generationState === 'success' && generatedClip && (
                         <video src="https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/360/Big_Buck_Bunny_360_10s_1MB.mp4" className="w-full h-full object-contain" autoPlay muted loop controls />
                    )}
                     {generationState === 'idle' && (
                         <div className="text-center text-gray-600"><CubeTransparentIcon className="w-24 h-24 mx-auto"/><p className="mt-4">Your AI-generated clips will appear here.</p></div>
                    )}
                </div>

                {/* Right Panel: Asset Drawer */}
                <div className="bg-gray-800 rounded-lg border border-gray-700/50 flex flex-col">
                    <h3 className="p-4 text-lg font-bold border-b border-gray-700/50">Asset Drawer</h3>
                     <div className="p-4 flex-1 space-y-4 overflow-y-auto">
                        <h4 className="text-sm font-semibold text-gray-400">Session History</h4>
                        <div className="space-y-2">
                            {generatedClip && (
                                 <div className="bg-gray-700/50 p-2 rounded-lg flex items-center gap-2 border-2 border-indigo-500">
                                    <img src={generatedClip.thumbnailUrl} className="w-16 h-10 object-cover rounded-md" />
                                    <p className="text-xs text-white flex-1 truncate">{generatedClip.title}</p>
                                </div>
                            )}
                        </div>
                     </div>
                </div>
            </div>

            {/* Bottom Panel: Timeline */}
            <div id="timeline-panel" className="flex-shrink-0 mt-6">
                <h3 className="text-lg font-bold mb-2">Timeline</h3>
                <div className="bg-gray-800 rounded-lg p-3 border border-gray-700/50 min-h-[100px] flex items-center gap-2">
                    <div className="w-full h-20 bg-gray-900/50 rounded flex items-center justify-center text-gray-600">
                        {timelineClips.length > 0 ? "Timeline clips here" : "Clips from the Co-Director will appear here."}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ClipGenStudio;
